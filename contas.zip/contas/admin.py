from django.contrib import admin
from .models import Lancamento

@admin.register(Lancamento)
class LancamentoAdmin(admin.ModelAdmin):
    list_display = ('descricao', 'valor', 'tipo', 'categoria', 'data')
    list_filter = ('tipo', 'categoria')
    search_fields = ('descricao',)
