from django import forms
from .models import Lancamento
from django.utils.translation import gettext_lazy as _
from .models import Categoria

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nome']

class LancamentoForm(forms.ModelForm):
    data = forms.DateField(
        input_formats=['%d/%m/%Y'],
        widget=forms.DateInput(format='%d/%m/%Y', attrs={'placeholder': 'dd/mm/aaaa', 'class': 'form-control'}),
        label='Data',
        error_messages={'invalid': _('Digite uma data válida no formato dd/mm/aaaa.')}
    )

    class Meta:
        model = Lancamento
        fields = ['descricao', 'valor', 'tipo', 'categoria', 'data']
