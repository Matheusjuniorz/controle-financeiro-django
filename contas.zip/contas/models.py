from django.db import models
from django.contrib.auth.models import User

TIPOS = [
    ('R', 'Receita'),
    ('D', 'Despesa'),
]


class Categoria(models.Model):
    nome = models.CharField(max_length=50)

    def __str__(self):
        return self.nome


class Lancamento(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    descricao = models.CharField(max_length=100)
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    tipo = models.CharField(max_length=1, choices=TIPOS)
    categoria = models.CharField(max_length=50)
    data = models.DateField()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)


    def __str__(self):
        return f'{self.descricao} - R${self.valor:.2f}'
