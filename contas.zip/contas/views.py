from django.shortcuts import render, redirect, get_object_or_404
from .models import Lancamento, Categoria
from .forms import LancamentoForm, CategoriaForm
from django.utils.dateparse import parse_date
from django.db.models import Sum  
from datetime import datetime
from django.http import HttpResponse
import csv
import openpyxl
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth import views as auth_views
from calendar import month_name
from django.db.models.functions import TruncMonth
from django.utils.timezone import now
from django.db.models.functions import ExtractYear


@login_required
def dashboard_mensal(request):
    # Pegando o ano via GET
    ano = request.GET.get('ano')
    if ano is None:
        ano = now().year
    else:
        try:
            ano = int(ano)
        except ValueError:
            ano = now().year

    # Buscar os anos disponíveis dos lançamentos do usuário
    anos_disponiveis = (
        Lancamento.objects
        .filter(user=request.user)
        .annotate(ano=ExtractYear('data'))
        .values_list('ano', flat=True)
        .distinct()
        .order_by('ano')
    )

    # Agrupar os lançamentos por mês
    lancamentos = (
        Lancamento.objects
        .filter(user=request.user, data__year=ano)
        .annotate(mes=TruncMonth('data'))
        .values('mes', 'tipo')
        .annotate(total=Sum('valor'))
        .order_by('mes')
    )

    # Preparar os dados
    meses = []
    receitas = []
    despesas = []

    for lanc in lancamentos:
        nome_mes = lanc['mes'].strftime('%b %Y')
        if nome_mes not in meses:
            meses.append(nome_mes)

        if lanc['tipo'] == 'R':
            receitas.append(float(lanc['total']))
        else:
            despesas.append(float(lanc['total']))

    while len(receitas) < len(meses):
        receitas.append(0)
    while len(despesas) < len(meses):
        despesas.append(0)

    context = {
        'ano': ano,
        'anos_disponiveis': anos_disponiveis,
        'meses': meses,
        'receitas': receitas,
        'despesas': despesas,
    }

    return render(request, 'contas/dashboard_mensal.html', context)



def sair(request):
    logout(request)
    return redirect('contas:listar_lancamentos')


def listar_categorias(request):
    categorias = Categoria.objects.all()
    return render(request, 'contas/categorias.html', {'categorias': categorias})

def adicionar_categoria(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('contas:listar_categorias')
    else:
        form = CategoriaForm()
    return render(request, 'contas/adicionar_categoria.html', {'form': form})


def editar_categoria(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            return redirect('contas:listar_categorias')
    else:
        form = CategoriaForm(instance=categoria)
    return render(request, 'contas/editar_categoria.html', {'form': form, 'categoria': categoria})


def deletar_categoria(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        categoria.delete()
        return redirect('contas:listar_categorias')
    return render(request, 'contas/deletar_categoria.html', {'categoria': categoria})


@login_required
def exportar_excel(request):
    lancamentos = Lancamento.objects.all()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Lançamentos"
    ws.append(['Descrição', 'Valor', 'Tipo', 'Categoria', 'Data'])

    for l in lancamentos:
        ws.append([
            l.descricao,
            float(l.valor),
            'Receita' if l.tipo == 'R' else 'Despesa',
            l.categoria.nome if l.categoria else '',
            l.data.strftime('%d/%m/%Y'),
        ])

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=lancamentos.xlsx'
    wb.save(response)
    return response


@login_required
def exportar_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="lancamentos.csv"'

    writer = csv.writer(response)
    writer.writerow(['Descrição', 'Valor', 'Tipo', 'Categoria', 'Data'])

    lancamentos = Lancamento.objects.all()
    for l in lancamentos:
        tipo = 'Receita' if l.tipo == 'R' else 'Despesa'
        writer.writerow([l.descricao, l.valor, tipo, l.categoria.nome, l.data])

    return response


@login_required
def adicionar_lancamento(request):
    if request.method == 'POST':
        form = LancamentoForm(request.POST)
        if form.is_valid():
            lancamento = form.save(commit=False)
            lancamento.user = request.user
            lancamento.save()
            return redirect('contas:listar_lancamentos')
    else:
        form = LancamentoForm()
    return render(request, 'contas/adicionar.html', {'form': form})


@login_required
def editar_lancamento(request, pk):
    lancamento = get_object_or_404(Lancamento, pk=pk)
    if request.method == 'POST':
        form = LancamentoForm(request.POST, instance=lancamento)
        if form.is_valid():
            form.save()
            return redirect('contas:listar_lancamentos')
    else:
        form = LancamentoForm(instance=lancamento)

    return render(request, 'contas/editar.html', {'form': form, 'lancamento': lancamento})


@login_required
def deletar_lancamento(request, pk):
    lancamento = get_object_or_404(Lancamento, pk=pk)
    if request.method == 'POST':
        lancamento.delete()
        return redirect('contas:listar_lancamentos')
    return render(request, 'contas/deletar.html', {'lancamento': lancamento})


@login_required
def listar_lancamentos(request):
    lancamentos = Lancamento.objects.filter(user=request.user).order_by('-data')
    categorias = Categoria.objects.all()

    data_inicio = request.GET.get('data_inicio')
    data_fim = request.GET.get('data_fim')
    categoria_id = request.GET.get('categoria')

    if data_inicio:
        lancamentos = lancamentos.filter(data__gte=data_inicio)
    if data_fim:
        lancamentos = lancamentos.filter(data__lte=data_fim)
    if categoria_id:
        lancamentos = lancamentos.filter(categoria__id=categoria_id)

    total_receitas = lancamentos.filter(tipo='R').aggregate(Sum('valor'))['valor__sum'] or 0
    total_despesas = lancamentos.filter(tipo='D').aggregate(Sum('valor'))['valor__sum'] or 0
    saldo = total_receitas - total_despesas

    grafico_pizza = {
        'labels': ['Receitas', 'Despesas'],
        'dados': [float(total_receitas), float(total_despesas)]
    }

    meses = []
    receitas_por_mes = []
    despesas_por_mes = []

    lancamentos_ordenados = lancamentos.order_by('data')

    for lanc in lancamentos_ordenados:
        mes_formatado = lanc.data.strftime('%b %Y')
        if mes_formatado not in meses:
            meses.append(mes_formatado)

    for mes in meses:
        dt = datetime.strptime(mes, '%b %Y')
        receitas_mes = lancamentos.filter(tipo='R', data__month=dt.month, data__year=dt.year).aggregate(Sum('valor'))['valor__sum'] or 0
        despesas_mes = lancamentos.filter(tipo='D', data__month=dt.month, data__year=dt.year).aggregate(Sum('valor'))['valor__sum'] or 0

        receitas_por_mes.append(float(receitas_mes))
        despesas_por_mes.append(float(despesas_mes))

    grafico_barras = {
        'labels': meses,
        'receitas': receitas_por_mes,
        'despesas': despesas_por_mes
    }

    context = {
        'lancamentos': lancamentos,
        'total_receitas': total_receitas,
        'total_despesas': total_despesas,
        'saldo': saldo,
        'categorias': categorias,
        'categoria_selecionada': int(categoria_id) if categoria_id else None,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'grafico_pizza': grafico_pizza,
        'grafico_barras': grafico_barras,
    }

    return render(request, 'contas/lista.html', context)
