from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'contas'

urlpatterns = [
    path('', views.listar_lancamentos, name='listar_lancamentos'),
    path('adicionar/', views.adicionar_lancamento, name='adicionar_lancamento'),
    path('editar/<int:pk>/', views.editar_lancamento, name='editar_lancamento'),
    path('deletar/<int:pk>/', views.deletar_lancamento, name='deletar_lancamento'),
    path('exportar/csv/', views.exportar_csv, name='exportar_csv'),
    path('exportar/excel/', views.exportar_excel, name='exportar_excel'),
    path('login/', auth_views.LoginView.as_view(template_name='contas/login.html', redirect_authenticated_user=True), name='login'),
    path('categorias/', views.listar_categorias, name='listar_categorias'),
    path('categorias/adicionar/', views.adicionar_categoria, name='adicionar_categoria'),
    path('categorias/editar/<int:pk>/', views.editar_categoria, name='editar_categoria'),
    path('categorias/deletar/<int:pk>/', views.deletar_categoria, name='deletar_categoria'),
    path('logout/', auth_views.LogoutView.as_view(next_page='contas:login'), name='logout'),
    path('dashboard-mensal/', views.dashboard_mensal, name='dashboard_mensal'),
    path('dashboard-mensal/', views.dashboard_mensal, name='dashboard_mensal'),
]
